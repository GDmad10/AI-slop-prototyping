GhostIPA data directory. Discovered ghosts + T1/T2/T3 outputs live here.
